$(function() {
    var api = new apiQueries();



});
